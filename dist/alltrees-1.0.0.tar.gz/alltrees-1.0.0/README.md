# alltrees Package

Our package contains 
1.AVL Tree 
2.B Tree
3.B+ Tree
4.Binary Search Tree 
5.Red Black Tree. 
This package can be used for storing data and fast retrieval of the stored data. 
Different operations can be performed easily such as:
1.Insertion
2.Deletion
3.Searching
4.Determination of Height
5.Determination of Balancing factor
6.Finding Maximum element
7.Finding Minimum element
